/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <Stdlib.h>
#include <String.h>
#include <math.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/*
   * Measurement interface:
   * - PA4  ADC1_CH4
   * - PB0  ADC1_CH8
   * - PC1  ADC1_CH11
   * - PC0  ADC1_CH10
   * - PD3  OUT_SIGNAL
   * Bluetooth module interface:
   * - PG2  IN_STATE
   * - PG3  OUT_ENABLE
   * - PA0  UART4_TX
   * - PA1  UART4_RX
  */

#define DATA_MODE_DEFAULT_BAUDRATE  9600
#define COMMAND_MODE_BAUDRATE 		38400

#define RX_MAX_SIZE 	30


#define KP  3.0
#define KI  0.001

#define SIGNAL_PORT GPIOD
#define SIGNAL_PIN  GPIO_PIN_3

#define KEY_PORT    GPIOG
#define KEY_PIN     GPIO_PIN_3
#define STATE_PORT  GPIOG
#define STATE_PIN   GPIO_PIN_3
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
enum CommunicationMode {DATA, COMMAND};
volatile enum CommunicationMode CommunicationStatus = DATA;

enum UARTStatus {RX, WAIT, INIT};
volatile enum UARTStatus terminalUsartState = INIT;
volatile enum UARTStatus moduleUartState = INIT;

char status = 0, state = 0;

uint8_t rxChar = '\0';

uint32_t ADCChannels[4] = {ADC_CHANNEL_4, ADC_CHANNEL_8, ADC_CHANNEL_11, ADC_CHANNEL_10};

int data_mode_baudrate = DATA_MODE_DEFAULT_BAUDRATE;

double iL = 0.0;
double v_out = 0.0;
double v_in_grid = 0.0;
double i_out = 0.0;

double erro = 0.0, integral = 0.0;

double PI = 0.0;

double I_REF = 0.0;

typedef struct
{
	UART_HandleTypeDef * uart;
	volatile enum UARTStatus *state;
	int index;
	uint8_t buffer[RX_MAX_SIZE];
} uartHandler;

uartHandler terminalUart;
uartHandler moduleUart;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
int readUart(uartHandler *huart);
void clear_buffer(uartHandler *huart);
void switchModuleMode(int mode);
int moduleSetup();
double getValueFromADCChannel(uint32_t channel);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
int __io_putchar(int ch)
{
	HAL_UART_Transmit(&huart3, (uint8_t *)&ch, 1, HAL_MAX_DELAY);
	return ch;
}

int __io_getchar(void)
{
	uint8_t ch = 0;
	__HAL_UART_CLEAR_OREFLAG(&huart3);
	HAL_UART_Receive (&huart3, (uint8_t *)&ch, 1, HAL_MAX_DELAY);
	HAL_UART_Transmit(&huart3, (uint8_t *)&ch, 1, HAL_MAX_DELAY);
	return ch;
}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef*htim)
{
	if(htim->Instance == TIM7 && status == 1)
	{
		iL = getValueFromADCChannel(ADCChannels[0]);
		v_out = getValueFromADCChannel(ADCChannels[1]);
		v_in_grid = getValueFromADCChannel(ADCChannels[2]);
		i_out = getValueFromADCChannel(ADCChannels[3]);

		erro = 50.00 - v_out;          						// Controlo do tensão de saída (DC-Link Voltage)
		integral += erro;

		PI = KP*erro + KI*integral;

		I_REF = (((v_out*i_out)+PI)/(30*30))*v_in_grid; 	// Criação da corrente de referência

		if (abs(I_REF) > iL)
			HAL_GPIO_WritePin(SIGNAL_PORT, SIGNAL_PIN, GPIO_PIN_SET);
		else
			HAL_GPIO_WritePin(SIGNAL_PORT, SIGNAL_PIN, GPIO_PIN_RESET);
	}
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *UartHandle)
{
	if(UartHandle->Instance == UART4)
		moduleUartState = RX;
	else if(UartHandle->Instance == USART3)
		terminalUsartState = RX;
}

int readUart(uartHandler *huart)
{
	if(*(huart->state) == RX)
	{
		if(huart->index == RX_MAX_SIZE)
			huart->index = 0;
		else if(rxChar == '\r')
		{
			huart->buffer[huart->index]   = '\0';
			huart->index = 0;
			return 1;
		}

		huart->buffer[huart->index] = rxChar;
		huart->index++;
		*(huart->state) = WAIT;
		HAL_UART_Receive_IT(huart->uart, (uint8_t *)&rxChar, 1);
	}
	else if(*(huart->state) == INIT)
	{
		HAL_UART_Receive_IT(huart->uart, (uint8_t *)&rxChar, 1);
		*(huart->state) = WAIT;
	}
	return 0;
}

void clear_buffer(uartHandler *huart)
{
	for(int g=0; g<RX_MAX_SIZE; g++)
		huart->buffer[g] = '\0';

	*(huart->state) = WAIT;
	HAL_UART_Receive_IT(huart->uart, (uint8_t*)&rxChar, 1);
}

void switchModuleMode(int mode)
{
	if(mode)
	{
		CommunicationStatus = COMMAND;
		huart4.Instance->BRR = UART_BRR_SAMPLING8(HAL_RCC_GetPCLK2Freq(), COMMAND_MODE_BAUDRATE);
		HAL_GPIO_WritePin(KEY_PORT, KEY_PIN, GPIO_PIN_SET);
	}
	else
	{
		CommunicationStatus = DATA;
		huart4.Instance->BRR = UART_BRR_SAMPLING8(HAL_RCC_GetPCLK2Freq(), data_mode_baudrate);
		HAL_GPIO_WritePin(KEY_PORT, KEY_PIN, GPIO_PIN_RESET);
	}
}

int moduleSetup()
{
	switchModuleMode(1);
	return 0;
}

double getValueFromADCChannel(uint32_t channel)
{
	ADC_ChannelConfTypeDef sConfig = {0};

	sConfig.Channel = channel;
	sConfig.Rank = ADC_REGULAR_RANK_1;
	sConfig.SamplingTime = ADC_SAMPLETIME_3CYCLES;

	if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
	    Error_Handler();

	HAL_ADC_PollForConversion(&hadc1, HAL_MAX_DELAY);
	return (HAL_ADC_GetValue(&hadc1) * 3.3)/4095;
}

int compare_buffer(uint8_t * buffer1, uint8_t * buffer2, int bytes)
{
	for(int k=0; k<bytes; k++)
	{
		if(buffer1[k] != buffer2[k])
			return 0;
	}
	return 1;
}

void processCommand(uint8_t * buffer)
{
	if(compare_buffer(buffer, "EN", 2))
	{
		printf("Enabled\r\n");
		state = 1;
	}
	else if(compare_buffer(buffer, "DS", 2))
	{
		printf("Disabled\r\n");
		state = 2;
	}
	else if(compare_buffer(buffer, "IR", 2))
	{
		printf("Reading\r\n");
		state = 3;
	}
	else if(compare_buffer(buffer, "SR", 2))
	{
		printf("Stopped reading\r\n");
		state = 4;
	}
}

void stateWork()
{
	switch(state)
	{
	case 1:
		status = 1;
		break;
	case 2:
		status = 0;
		break;
	case 3:
		printf("iL: %d\nv_out: %d\nv_in_grid: %d\ni_out: %d\r\n",iL*1000, v_out*1000, v_in_grid*1000, i_out*1000);
		HAL_Delay(2000);
		break;
	case 4: break;
	default: break;
	}
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /*
   * Measurement interface:
   * - PA4  ADC1_CH4
   * - PB0  ADC1_CH8
   * - PC1  ADC1_CH11
   * - PC0  ADC1_CH10
   * - PD3  OUT_SIGNAL
   * Bluetooth module interface:
   * - PG2  IN
   * - PG3  OUT
   * - PA0  UART4_TX
   * - PA1  UART4_RX
  */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART3_UART_Init();
  MX_ADC1_Init();
  MX_TIM7_Init();
  MX_UART4_Init();
  /* USER CODE BEGIN 2 */
  setvbuf(stdin, NULL, _IONBF, 0);
  if (HAL_ADC_Start(&hadc1) != HAL_OK)
  {
	  printf("Failed to start ADC\r\n");
      Error_Handler();
  }

  if (HAL_TIM_Base_Start_IT(&htim7) != HAL_OK)
  {
	  printf("Failed to start Timer\r\n");
      Error_Handler();
  }

  terminalUart.uart = &huart3;
  terminalUart.state = &terminalUsartState;
  terminalUart.index = 0;
  for (int i = 0; i < RX_MAX_SIZE; ++i)
  {
	  terminalUart.buffer[i] = '\0';
  }

  moduleUart.uart = &huart4;
  moduleUart.state = &moduleUartState;
  moduleUart.index = 0;
  for (int i = 0; i < RX_MAX_SIZE; ++i)
  {
	  moduleUart.buffer[i] = '\0';
  }
  printf("Initiated\r\n");
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
	  if(readUart(&terminalUart))
	  {
		  processCommand(terminalUart.buffer);
		  clear_buffer(&terminalUart);
	  }

	  if(readUart(&moduleUart))
	  {
		  processCommand(moduleUart.buffer);
		  clear_buffer(&moduleUart);
	  }

	  stateWork();
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure LSE Drive Capability
  */
  HAL_PWR_EnableBkUpAccess();

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_BYPASS;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 96;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Activate the Over-Drive mode
  */
  if (HAL_PWREx_EnableOverDrive() != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
